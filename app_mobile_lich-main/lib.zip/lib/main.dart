import 'package:flutter/material.dart';

import 'screens/login_screen.dart';

// File main.dart là điểm bắt đầu của app.
// Khi bấm Run, Flutter sẽ chạy từ hàm main() này trước.
void main() {
  runApp(const ScheduleApp());
}

class ScheduleApp extends StatelessWidget {
  const ScheduleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Ẩn chữ DEBUG ở góc phải màn hình.
      debugShowCheckedModeBanner: false,

      title: 'Lịch giảng dạy',

      // Theme chung của toàn bộ app.
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB),
        ),
      ),

      // Màn hình đầu tiên là màn hình đăng nhập.
      home: const LoginScreen(),
    );
  }
}