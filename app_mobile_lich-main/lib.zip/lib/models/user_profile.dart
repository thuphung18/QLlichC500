// Model UserProfile mô tả thông tin người dùng đang đăng nhập.
// Sau này khi có API, dữ liệu user sẽ được trả về từ backend.

class UserProfile {
  final String id;
  final String fullName;
  final String username;
  final String role;
  final String unit;
  final String departmentId;
  final String departmentName;
  final String email;
  final String phone;

  const UserProfile({
    required this.id,
    required this.fullName,
    required this.username,
    required this.role,
    required this.unit,
    required this.departmentId,
    required this.departmentName,
    required this.email,
    required this.phone,
  });

  // Hàm fromJson dùng cho tương lai khi lấy user từ API.
  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id']?.toString() ?? '',
      fullName: json['fullName']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      role: json['role']?.toString() ?? '',
      unit: json['unit']?.toString() ?? '',
      departmentId: json['departmentId']?.toString() ?? '',
      departmentName: json['departmentName']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
    );
  }
}