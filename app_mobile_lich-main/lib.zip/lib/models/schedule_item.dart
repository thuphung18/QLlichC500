// Model ScheduleItem mô tả một lịch công tác / lịch giảng dạy.
// Sau này API trả JSON về thì app sẽ convert JSON thành ScheduleItem.

class ScheduleItem {
  final String id;
  final String title;
  final String teacher;
  final String room;
  final String dateLabel;
  final String startTime;
  final String endTime;
  final String session;
  final String note;
  final String unit;
  final String departmentId;
  final String departmentName;
  final String category;
  final List<String> participants;
  final List<String> participantUserIds;

  // isMine và isDepartment dùng để phân loại màu/giao diện.
  // Với dữ liệu thật sau này, logic này nên tính theo userId và departmentId.
  final bool isMine;
  final bool isDepartment;

  // dayIndex: thứ trong tuần.
  // 2 = thứ 2, 3 = thứ 3, ..., 8 = chủ nhật.
  final int dayIndex;

  const ScheduleItem({
    required this.id,
    required this.title,
    required this.teacher,
    required this.room,
    required this.dateLabel,
    required this.startTime,
    required this.endTime,
    required this.session,
    required this.note,
    required this.unit,
    required this.departmentId,
    required this.departmentName,
    required this.category,
    required this.participants,
    required this.participantUserIds,
    required this.isMine,
    required this.isDepartment,
    required this.dayIndex,
  });

  String get timeRange => '$startTime - $endTime';

  // Hàm này để sau này đọc dữ liệu từ API.
  factory ScheduleItem.fromJson(Map<String, dynamic> json) {
    return ScheduleItem(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? '',
      teacher: json['teacher']?.toString() ?? '',
      room: json['room']?.toString() ?? '',
      dateLabel: json['dateLabel']?.toString() ?? '',
      startTime: json['startTime']?.toString() ?? '',
      endTime: json['endTime']?.toString() ?? '',
      session: json['session']?.toString() ?? '',
      note: json['note']?.toString() ?? '',
      unit: json['unit']?.toString() ?? '',
      departmentId: json['departmentId']?.toString() ?? '',
      departmentName: json['departmentName']?.toString() ?? '',
      category: json['category']?.toString() ?? '',
      participants: _toStringList(json['participants']),
      participantUserIds: _toStringList(json['participantUserIds']),
      isMine: json['isMine'] == true,
      isDepartment: json['isDepartment'] == true,
      dayIndex: int.tryParse(json['dayIndex']?.toString() ?? '') ?? 2,
    );
  }

  static List<String> _toStringList(dynamic value) {
    if (value is List) {
      return value.map((item) => item.toString()).toList();
    }

    return [];
  }
}