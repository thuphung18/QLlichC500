import '../models/schedule_item.dart';

// ScheduleRepository là hợp đồng lấy dữ liệu lịch.
// Hiện tại dùng DemoScheduleRepository.
// Sau này thay bằng ApiScheduleRepository để gọi API + SQL Server.
abstract class ScheduleRepository {
  List<ScheduleItem> getAllSchedules();

  List<ScheduleItem> getSchedulesByDay(int dayIndex);

  List<ScheduleItem> getMySchedules();

  List<ScheduleItem> getDepartmentSchedules();

  List<ScheduleItem> searchSchedules(String keyword);
}