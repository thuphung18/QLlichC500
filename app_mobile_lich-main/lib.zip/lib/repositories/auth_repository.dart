import '../models/user_profile.dart';

// AuthRepository là lớp hợp đồng cho chức năng đăng nhập/quên mật khẩu.
// Hiện tại ta dùng DemoAuthRepository.
// Sau này làm thật thì tạo ApiAuthRepository gọi backend API.
abstract class AuthRepository {
  Future<UserProfile?> login({
    required String username,
    required String password,
  });

  Future<SendResetCodeResult> sendResetCode({
    required String contact,
  });

  Future<VerifyResetCodeResult> verifyResetCode({
    required String contact,
    required String code,
  });

  Future<bool> resetPassword({
    required String resetToken,
    required String newPassword,
  });
}

// Kết quả gửi mã OTP.
class SendResetCodeResult {
  final bool success;
  final String message;
  final String? maskedContact;

  // debugCode chỉ dùng trong demo để hiện mã OTP cho bạn test.
  // Sau này làm thật thì bỏ debugCode, mã sẽ gửi qua SMS/email.
  final String? debugCode;

  const SendResetCodeResult({
    required this.success,
    required this.message,
    this.maskedContact,
    this.debugCode,
  });
}

// Kết quả xác thực OTP.
class VerifyResetCodeResult {
  final bool success;
  final String message;

  // resetToken dùng để chứng minh người dùng đã nhập đúng OTP.
  // Sau này backend sẽ trả resetToken thật.
  final String? resetToken;

  const VerifyResetCodeResult({
    required this.success,
    required this.message,
    this.resetToken,
  });
}