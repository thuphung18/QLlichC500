import 'package:shared_preferences/shared_preferences.dart';

// File này dùng để lưu tài khoản/mật khẩu khi người dùng tick "Ghi nhớ".
// Đây là bản demo học tập.
// App thật nên lưu token, không nên lưu mật khẩu dạng thường.
class RememberLoginStorage {
  static const String _keyRemember = 'remember_login';
  static const String _keyUsername = 'remember_username';
  static const String _keyPassword = 'remember_password';

  Future<RememberedLogin?> load() async {
    final prefs = await SharedPreferences.getInstance();

    final remember = prefs.getBool(_keyRemember) ?? false;

    if (!remember) {
      return null;
    }

    final username = prefs.getString(_keyUsername) ?? '';
    final password = prefs.getString(_keyPassword) ?? '';

    if (username.isEmpty || password.isEmpty) {
      return null;
    }

    return RememberedLogin(
      username: username,
      password: password,
    );
  }

  Future<void> save({
    required String username,
    required String password,
  }) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(_keyRemember, true);
    await prefs.setString(_keyUsername, username);
    await prefs.setString(_keyPassword, password);
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(_keyRemember, false);
    await prefs.remove(_keyUsername);
    await prefs.remove(_keyPassword);
  }
}

class RememberedLogin {
  final String username;
  final String password;

  const RememberedLogin({
    required this.username,
    required this.password,
  });
}