import 'package:flutter/material.dart';

import '../models/schedule_item.dart';
import '../repositories/schedule_repository.dart';
import '../widgets/app_header.dart';
import '../widgets/empty_state.dart';
import '../widgets/schedule_card.dart';
import 'schedule_detail_screen.dart';

// SearchScheduleScreen là màn hình tìm kiếm lịch.
// Người dùng có thể tìm theo tên lịch, phòng, đơn vị, người phụ trách...
class SearchScheduleScreen extends StatefulWidget {
  final ScheduleRepository repository;

  const SearchScheduleScreen({
    super.key,
    required this.repository,
  });

  @override
  State<SearchScheduleScreen> createState() => _SearchScheduleScreenState();
}

class _SearchScheduleScreenState extends State<SearchScheduleScreen> {
  final TextEditingController _controller = TextEditingController();

  String _keyword = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final results = widget.repository.searchSchedules(_keyword);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const AppHeader(
          title: 'TÌM KIẾM',
          subtitle: 'Tra cứu lịch theo tên, phòng, đơn vị hoặc người phụ trách',
          icon: Icons.search,
          accentColor: Color(0xFF7C3AED),
        ),

        const SizedBox(height: 16),

        TextField(
          controller: _controller,
          onChanged: (value) {
            setState(() {
              _keyword = value;
            });
          },
          decoration: InputDecoration(
            hintText: 'Nhập từ khóa tìm kiếm...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: BorderSide.none,
            ),
          ),
        ),

        const SizedBox(height: 18),

        if (results.isEmpty)
          const EmptyState(
            icon: Icons.manage_search,
            title: 'Không tìm thấy lịch',
            message: 'Thử nhập từ khóa khác để tìm kiếm.',
          )
        else
          ...results.map(
                (item) => ScheduleCard(
              item: item,
              accentColor: _getColorByItem(item),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ScheduleDetailScreen(
                      item: item,
                      accentColor: _getColorByItem(item),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  Color _getColorByItem(ScheduleItem item) {
    if (item.isMine) {
      return const Color(0xFF2563EB);
    }

    if (item.isDepartment) {
      return const Color(0xFF0F766E);
    }

    return const Color(0xFF7C3AED);
  }
}