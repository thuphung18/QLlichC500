import 'package:flutter/material.dart';

import '../models/schedule_item.dart';
import '../repositories/schedule_repository.dart';
import '../widgets/app_header.dart';
import '../widgets/day_selector.dart';
import '../widgets/empty_state.dart';
import '../widgets/schedule_summary_card.dart';
import '../widgets/session_section.dart';

// MyScheduleScreen là màn hình "Lịch của tôi".
// Dữ liệu lấy từ repository.getMySchedules().
// Repository sẽ tự lọc lịch theo user đang đăng nhập.
class MyScheduleScreen extends StatefulWidget {
  final ScheduleRepository repository;

  const MyScheduleScreen({
    super.key,
    required this.repository,
  });

  @override
  State<MyScheduleScreen> createState() => _MyScheduleScreenState();
}

class _MyScheduleScreenState extends State<MyScheduleScreen> {
  int _selectedDayIndex = 2;

  @override
  Widget build(BuildContext context) {
    final schedules = widget.repository
        .getMySchedules()
        .where((item) => item.dayIndex == _selectedDayIndex)
        .toList();

    final morningItems = _filterBySession(schedules, 'morning');
    final afternoonItems = _filterBySession(schedules, 'afternoon');
    final eveningItems = _filterBySession(schedules, 'evening');

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const AppHeader(
          title: 'LỊCH CỦA TÔI',
          subtitle: 'Các lịch có liên quan trực tiếp đến bạn',
          icon: Icons.person_pin_circle,
          accentColor: Color(0xFF2563EB),
        ),

        const SizedBox(height: 16),

        DaySelector(
          selectedDayIndex: _selectedDayIndex,
          onChanged: (value) {
            setState(() {
              _selectedDayIndex = value;
            });
          },
        ),

        const SizedBox(height: 18),

        ScheduleSummaryCard(
          totalCount: schedules.length,
          morningCount: morningItems.length,
          afternoonCount: afternoonItems.length,
          eveningCount: eveningItems.length,
          accentColor: const Color(0xFF2563EB),
          title: 'Tổng quan lịch của tôi',
          subtitle: 'Thống kê các lịch liên quan trực tiếp đến bạn',
        ),

        const SizedBox(height: 18),

        if (schedules.isEmpty)
          const EmptyState(
            icon: Icons.person_off,
            title: 'Bạn chưa có lịch',
            message: 'Ngày này chưa có lịch cá nhân nào.',
          )
        else ...[
          SessionSection(
            title: 'SÁNG',
            icon: Icons.wb_sunny,
            items: morningItems,
            accentColor: const Color(0xFF2563EB),
          ),
          SessionSection(
            title: 'CHIỀU',
            icon: Icons.brightness_5,
            items: afternoonItems,
            accentColor: const Color(0xFFF97316),
          ),
          SessionSection(
            title: 'TỐI',
            icon: Icons.nights_stay,
            items: eveningItems,
            accentColor: const Color(0xFF7C3AED),
          ),
        ],
      ],
    );
  }

  List<ScheduleItem> _filterBySession(
      List<ScheduleItem> items,
      String session,
      ) {
    return items.where((item) => item.session == session).toList();
  }
}