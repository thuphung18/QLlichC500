import 'package:flutter/material.dart';

import '../models/schedule_item.dart';
import '../repositories/schedule_repository.dart';
import '../widgets/app_header.dart';
import '../widgets/day_selector.dart';
import '../widgets/empty_state.dart';
import '../widgets/schedule_summary_card.dart';
import '../widgets/session_section.dart';

// WeekScheduleScreen là màn hình "Lịch tuần".
// Chức năng:
// 1. Chọn thứ trong tuần.
// 2. Hiển thị tổng số lịch theo ngày.
// 3. Chia lịch thành sáng / chiều / tối.
// 4. Bấm vào từng lịch để xem chi tiết.
class WeekScheduleScreen extends StatefulWidget {
  final ScheduleRepository repository;

  const WeekScheduleScreen({
    super.key,
    required this.repository,
  });

  @override
  State<WeekScheduleScreen> createState() => _WeekScheduleScreenState();
}

class _WeekScheduleScreenState extends State<WeekScheduleScreen> {
  // Mặc định đang chọn thứ 2.
  int _selectedDayIndex = 2;

  @override
  Widget build(BuildContext context) {
    // Lấy danh sách lịch theo ngày đang chọn.
    final schedules = widget.repository.getSchedulesByDay(_selectedDayIndex);

    // Tách lịch theo buổi.
    final morningItems = _filterBySession(schedules, 'morning');
    final afternoonItems = _filterBySession(schedules, 'afternoon');
    final eveningItems = _filterBySession(schedules, 'evening');

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const AppHeader(
          title: 'LỊCH TUẦN',
          subtitle: 'Từ 08/6 - 14/6/2026',
          icon: Icons.calendar_month,
          accentColor: Color(0xFF2563EB),
        ),

        const SizedBox(height: 16),

        DaySelector(
          selectedDayIndex: _selectedDayIndex,
          onChanged: (value) {
            setState(() {
              _selectedDayIndex = value;
            });
          },
        ),

        const SizedBox(height: 18),

        ScheduleSummaryCard(
          totalCount: schedules.length,
          morningCount: morningItems.length,
          afternoonCount: afternoonItems.length,
          eveningCount: eveningItems.length,
          accentColor: const Color(0xFF2563EB),
          title: 'Tổng quan lịch tuần',
          subtitle: 'Thống kê theo ngày đang chọn',
        ),

        const SizedBox(height: 18),

        if (schedules.isEmpty)
          const EmptyState(
            icon: Icons.event_busy,
            title: 'Không có lịch',
            message: 'Ngày này chưa có lịch công tác hoặc lịch giảng dạy.',
          )
        else ...[
          SessionSection(
            title: 'SÁNG',
            icon: Icons.wb_sunny,
            items: morningItems,
            accentColor: const Color(0xFF2563EB),
          ),
          SessionSection(
            title: 'CHIỀU',
            icon: Icons.brightness_5,
            items: afternoonItems,
            accentColor: const Color(0xFFF97316),
          ),
          SessionSection(
            title: 'TỐI',
            icon: Icons.nights_stay,
            items: eveningItems,
            accentColor: const Color(0xFF7C3AED),
          ),
        ],
      ],
    );
  }

  List<ScheduleItem> _filterBySession(
      List<ScheduleItem> items,
      String session,
      ) {
    return items.where((item) => item.session == session).toList();
  }
}