import 'package:flutter/material.dart';

import '../data/demo_schedule_repository.dart';
import '../models/user_profile.dart';
import 'department_schedule_screen.dart';
import 'my_schedule_screen.dart';
import 'profile_screen.dart';
import 'search_schedule_screen.dart';
import 'week_schedule_screen.dart';

// MainShell là khung chính sau khi đăng nhập.
// Nó chứa BottomNavigationBar để chuyển giữa các tab:
// 1. Lịch tuần
// 2. Lịch của tôi
// 3. Lịch khoa
// 4. Tìm kiếm
// 5. Cá nhân
class MainShell extends StatefulWidget {
  final UserProfile currentUser;

  const MainShell({
    super.key,
    required this.currentUser,
  });

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _selectedIndex = 0;

  late final DemoScheduleRepository _repository;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();

    // Repository nhận currentUser để lọc lịch theo đúng người đang đăng nhập.
    _repository = DemoScheduleRepository(
      currentUser: widget.currentUser,
    );

    _pages = [
      WeekScheduleScreen(repository: _repository),
      MyScheduleScreen(repository: _repository),
      DepartmentScheduleScreen(
        repository: _repository,
        departmentName: widget.currentUser.departmentName,
      ),
      SearchScheduleScreen(repository: _repository),
      ProfileScreen(profile: widget.currentUser),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      body: SafeArea(
        child: IndexedStack(
          index: _selectedIndex,
          children: _pages,
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(12),
              blurRadius: 18,
              offset: const Offset(0, -6),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          selectedItemColor: const Color(0xFF2563EB),
          unselectedItemColor: const Color(0xFF94A3B8),
          selectedLabelStyle: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
          unselectedLabelStyle: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.calendar_month),
              label: 'Lịch tuần',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_pin_circle),
              label: 'Lịch của tôi',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.business),
              label: 'Lịch khoa',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.search),
              label: 'Tìm kiếm',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.account_circle),
              label: 'Cá nhân',
            ),
          ],
        ),
      ),
    );
  }
}