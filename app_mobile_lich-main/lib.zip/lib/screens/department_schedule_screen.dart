import 'package:flutter/material.dart';

import '../models/schedule_item.dart';
import '../repositories/schedule_repository.dart';
import '../widgets/app_header.dart';
import '../widgets/day_selector.dart';
import '../widgets/empty_state.dart';
import '../widgets/schedule_summary_card.dart';
import '../widgets/session_section.dart';

// DepartmentScheduleScreen là màn hình "Lịch khoa".
// Không fix cứng Khoa Công nghệ thông tin nữa.
// departmentName được truyền từ user đang đăng nhập.
class DepartmentScheduleScreen extends StatefulWidget {
  final ScheduleRepository repository;
  final String departmentName;

  const DepartmentScheduleScreen({
    super.key,
    required this.repository,
    required this.departmentName,
  });

  @override
  State<DepartmentScheduleScreen> createState() {
    return _DepartmentScheduleScreenState();
  }
}

class _DepartmentScheduleScreenState extends State<DepartmentScheduleScreen> {
  int _selectedDayIndex = 2;

  @override
  Widget build(BuildContext context) {
    final schedules = widget.repository
        .getDepartmentSchedules()
        .where((item) => item.dayIndex == _selectedDayIndex)
        .toList();

    final morningItems = _filterBySession(schedules, 'morning');
    final afternoonItems = _filterBySession(schedules, 'afternoon');
    final eveningItems = _filterBySession(schedules, 'evening');

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        AppHeader(
          title: 'LỊCH CỦA KHOA',
          subtitle: 'Lịch chung của ${widget.departmentName}',
          icon: Icons.business,
          accentColor: const Color(0xFF0F766E),
        ),

        const SizedBox(height: 16),

        DaySelector(
          selectedDayIndex: _selectedDayIndex,
          onChanged: (value) {
            setState(() {
              _selectedDayIndex = value;
            });
          },
        ),

        const SizedBox(height: 18),

        ScheduleSummaryCard(
          totalCount: schedules.length,
          morningCount: morningItems.length,
          afternoonCount: afternoonItems.length,
          eveningCount: eveningItems.length,
          accentColor: const Color(0xFF0F766E),
          title: 'Tổng quan lịch khoa',
          subtitle: 'Thống kê lịch chung của khoa theo ngày',
        ),

        const SizedBox(height: 18),

        if (schedules.isEmpty)
          const EmptyState(
            icon: Icons.business,
            title: 'Chưa có lịch của khoa',
            message: 'Ngày này khoa chưa có lịch công tác chung.',
          )
        else ...[
          SessionSection(
            title: 'SÁNG',
            icon: Icons.wb_sunny,
            items: morningItems,
            accentColor: const Color(0xFF0F766E),
          ),
          SessionSection(
            title: 'CHIỀU',
            icon: Icons.brightness_5,
            items: afternoonItems,
            accentColor: const Color(0xFFF97316),
          ),
          SessionSection(
            title: 'TỐI',
            icon: Icons.nights_stay,
            items: eveningItems,
            accentColor: const Color(0xFF7C3AED),
          ),
        ],
      ],
    );
  }

  List<ScheduleItem> _filterBySession(
      List<ScheduleItem> items,
      String session,
      ) {
    return items.where((item) => item.session == session).toList();
  }
}